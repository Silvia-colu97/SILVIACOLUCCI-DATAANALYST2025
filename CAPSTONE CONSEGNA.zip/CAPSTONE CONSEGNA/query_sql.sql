-- QUERY 1: PANORAMICA GENERALE -- Quanto è grande il dataset?
SELECT 
    COUNT(*) AS totale_rilevazioni,
    COUNT(DISTINCT id_gioco) AS giochi_unici,
    COUNT(DISTINCT id_competitor) AS siti_competitor,
    ROUND(AVG(prezzo_attuale), 2) AS prezzo_medio_generale,
    MIN(prezzo_attuale) AS prezzo_min,
    MAX(prezzo_attuale) AS prezzo_max
FROM prezzo_rilevato;

-- QUERY 2: CONFRONTO PREZZI MEDI PER COMPETITOR: Quale sito è mediamente più economico?
SELECT 
    c.nome_sito,
    COUNT(*) AS num_prodotti,
    ROUND(AVG(pr.prezzo_attuale), 2) AS prezzo_medio,
    ROUND(MIN(pr.prezzo_attuale), 2) AS prezzo_min,
    ROUND(MAX(pr.prezzo_attuale), 2) AS prezzo_max,
    ROUND(STDDEV(pr.prezzo_attuale), 2) AS deviazione_std
FROM prezzo_rilevato pr
JOIN competitor c ON pr.id_competitor = c.id_competitor
GROUP BY c.id_competitor, c.nome_sito
ORDER BY prezzo_medio;

-- QUERY 3: TOP 20 PUBLISHER PIÙ PRESENTI NEI COMPETITOR Quali publisher dominano l'offerta italiana?
SELECT 
    SUBSTRING_INDEX(publisher, ';', 1) AS publisher_principale,
    COUNT(DISTINCT g.id_gioco) AS num_giochi,
    ROUND(AVG(pr.prezzo_attuale), 2) AS prezzo_medio
FROM gioco g
JOIN prezzo_rilevato pr ON g.id_gioco = pr.id_gioco
WHERE publisher IS NOT NULL
GROUP BY publisher_principale
ORDER BY num_giochi DESC
LIMIT 20;

-- QUERY 4: GIOCHI CON LA MAGGIORE VARIANZA DI PREZZO TRA SITI Su quali giochi conviene comparare i prezzi prima di comprare?
SELECT 
    g.nome_originale,
    LEFT(g.publisher, 40) AS publisher,
    COUNT(DISTINCT pr.id_competitor) AS num_siti,
    ROUND(MIN(pr.prezzo_attuale), 2) AS prezzo_min,
    ROUND(MAX(pr.prezzo_attuale), 2) AS prezzo_max,
    ROUND(MAX(pr.prezzo_attuale) - MIN(pr.prezzo_attuale), 2) AS differenza_euro,
    ROUND(
        (MAX(pr.prezzo_attuale) - MIN(pr.prezzo_attuale)) / MIN(pr.prezzo_attuale) * 100, 
        1
    ) AS differenza_percent
FROM prezzo_rilevato pr
JOIN gioco g ON pr.id_gioco = g.id_gioco
GROUP BY g.id_gioco, g.nome_originale, g.publisher
HAVING num_siti >= 2 AND prezzo_min >= 5
ORDER BY differenza_percent DESC
LIMIT 20;


-- QUERY 5: DISTRIBUZIONE PER FASCIA DI PREZZO Come è strutturata l'offerta per fascia di prezzo?
SELECT 
    fascia_prezzo,
    COUNT(*) AS num_prodotti,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 1) AS percentuale,
    ROUND(AVG(prezzo_attuale), 2) AS prezzo_medio_fascia
FROM (
    SELECT 
        prezzo_attuale,
        CASE 
            WHEN prezzo_attuale < 15 THEN '1. Entry (< 15€)'
            WHEN prezzo_attuale < 30 THEN '2. Mass (15-30€)'
            WHEN prezzo_attuale < 60 THEN '3. Mid (30-60€)'
            WHEN prezzo_attuale < 100 THEN '4. Premium (60-100€)'
            ELSE '5. Luxury (100€+)'
        END AS fascia_prezzo
    FROM prezzo_rilevato
) AS sub
GROUP BY fascia_prezzo
ORDER BY fascia_prezzo;

-- QUERY 6: CORRELAZIONE TRA RATING BGG E PREZZO I giochi più amati costano di più? Ci sono outlier interessanti?
SELECT 
    CASE 
        WHEN g.rating_bgg < 6 THEN '1. Sotto media (< 6)'
        WHEN g.rating_bgg < 7 THEN '2. Discreti (6-7)'
        WHEN g.rating_bgg < 7.5 THEN '3. Buoni (7-7.5)'
        WHEN g.rating_bgg < 8 THEN '4. Ottimi (7.5-8)'
        ELSE '5. Top (8+)'
    END AS fascia_rating,
    COUNT(*) AS num_giochi,
    ROUND(AVG(pr.prezzo_attuale), 2) AS prezzo_medio,
    ROUND(MIN(pr.prezzo_attuale), 2) AS prezzo_min,
    ROUND(MAX(pr.prezzo_attuale), 2) AS prezzo_max
FROM prezzo_rilevato pr
JOIN gioco g ON pr.id_gioco = g.id_gioco
WHERE g.rating_bgg IS NOT NULL
GROUP BY fascia_rating
ORDER BY fascia_rating;

-- QUERY 7: TOP 10 GIOCHI PIÙ SCONTATI Dove sono le promozioni più aggressive?
SELECT 
    g.nome_originale,
    c.nome_sito,
    LEFT(g.publisher, 40) AS publisher,
    pr.prezzo_originale,
    pr.prezzo_attuale,
    pr.sconto_percent
FROM prezzo_rilevato pr
JOIN gioco g ON pr.id_gioco = g.id_gioco
JOIN competitor c ON pr.id_competitor = c.id_competitor
WHERE pr.sconto_percent IS NOT NULL 
  AND pr.sconto_percent >= 10
ORDER BY pr.sconto_percent DESC
LIMIT 20;

-- QUERY 8: PREZZO MEDIO PER ANNO DI USCITA DEL GIOCO I giochi più recenti costano di più?
SELECT 
    g.anno_uscita,
    COUNT(DISTINCT g.id_gioco) AS num_giochi,
    ROUND(AVG(pr.prezzo_attuale), 2) AS prezzo_medio
FROM prezzo_rilevato pr
JOIN gioco g ON pr.id_gioco = g.id_gioco
WHERE g.anno_uscita IS NOT NULL 
  AND g.anno_uscita BETWEEN 2010 AND 2026
GROUP BY g.anno_uscita
HAVING num_giochi >= 5
ORDER BY g.anno_uscita DESC;


-- QUERY 9: ANALISI PER CATEGORIA DI GIOCO (BGG THEMES) Le categorie più presenti e i loro prezzi medi 
SELECT 
    SUBSTRING_INDEX(g.categoria, ';', 1) AS categoria_principale,
    COUNT(DISTINCT g.id_gioco) AS num_giochi,
    ROUND(AVG(pr.prezzo_attuale), 2) AS prezzo_medio,
    ROUND(AVG(g.rating_bgg), 2) AS rating_medio
FROM prezzo_rilevato pr
JOIN gioco g ON pr.id_gioco = g.id_gioco
WHERE g.categoria IS NOT NULL
GROUP BY categoria_principale
HAVING num_giochi >= 5
ORDER BY num_giochi DESC
LIMIT 15;

-- QUERY 10: COMPETITIVITÀ DEI SITI — chi è "best price" più spesso? 
WITH ranking_prezzi AS (
    SELECT 
        pr.id_gioco,
        pr.id_competitor,
        pr.prezzo_attuale,
        RANK() OVER (PARTITION BY pr.id_gioco ORDER BY pr.prezzo_attuale ASC) AS rank_prezzo
    FROM prezzo_rilevato pr
    WHERE pr.id_gioco IN (
        SELECT id_gioco
        FROM prezzo_rilevato
        GROUP BY id_gioco
        HAVING COUNT(DISTINCT id_competitor) >= 2
    )
)
SELECT 
    c.nome_sito,
    COUNT(*) AS volte_miglior_prezzo,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 1) AS percentuale_vittorie
FROM ranking_prezzi rp
JOIN competitor c ON rp.id_competitor = c.id_competitor
WHERE rp.rank_prezzo = 1
GROUP BY c.nome_sito
ORDER BY volte_miglior_prezzo DESC;

-- QUERY 11: STORIA DEI PREZZI (per dashboard temporale Power BI)
SELECT 
    d.data_completa,
    c.nome_sito,
    COUNT(*) AS num_rilevazioni,
    ROUND(AVG(pr.prezzo_attuale), 2) AS prezzo_medio_giorno
FROM prezzo_rilevato pr
JOIN dim_data d ON pr.id_data = d.id_data
JOIN competitor c ON pr.id_competitor = c.id_competitor
GROUP BY d.data_completa, c.nome_sito
ORDER BY d.data_completa DESC, prezzo_medio_giorno;

-- QUERY 12: GIOCHI "VALUE" (alto rating BGG, basso prezzo) I giochi più convenienti rispetto alla qualità
SELECT 
    g.nome_originale,
    LEFT(g.publisher, 40) AS publisher,
    g.rating_bgg,
    ROUND(AVG(pr.prezzo_attuale), 2) AS prezzo_medio,
    ROUND(g.rating_bgg / AVG(pr.prezzo_attuale) * 10, 3) AS value_score
FROM prezzo_rilevato pr
JOIN gioco g ON pr.id_gioco = g.id_gioco
WHERE g.rating_bgg >= 7.5
GROUP BY g.id_gioco, g.nome_originale, g.publisher, g.rating_bgg
HAVING prezzo_medio BETWEEN 10 AND 50
ORDER BY value_score DESC
LIMIT 20;
