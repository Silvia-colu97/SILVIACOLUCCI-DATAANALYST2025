CREATE TABLE competitor (
    id_competitor   INT AUTO_INCREMENT PRIMARY KEY,
    nome_sito       VARCHAR(100) NOT NULL UNIQUE,
    url_base        VARCHAR(255) NOT NULL,
    tipo_canale     VARCHAR(50) DEFAULT 'specialty store',
    paese           VARCHAR(50) DEFAULT 'Italia',
    note            VARCHAR(255),
    
    INDEX idx_nome (nome_sito)
) ENGINE=InnoDB COMMENT='Anagrafica siti competitor scrapati';

-- =====================================================================
-- 3. TABELLA DIMENSIONE: GIOCO
-- =====================================================================
-- Anagrafica dei giochi con metadati arricchiti da BoardGameGeek
CREATE TABLE gioco (
    id_gioco            INT AUTO_INCREMENT PRIMARY KEY,
    nome_originale      VARCHAR(255) NOT NULL,
    nome_normalizzato   VARCHAR(255),
    bgg_id              INT,
    nome_bgg            VARCHAR(255),
    anno_uscita         INT,
    publisher           TEXT,
    designer            TEXT,
    categoria           TEXT,
    meccaniche          TEXT,
    rating_bgg          DECIMAL(3,2),
    complessita_bgg     DECIMAL(3,2),
    rating_bayesiano    DECIMAL(4,3),
    rank_bgg            INT,
    min_giocatori       INT,
    max_giocatori       INT,
    durata_min          INT,
    
    INDEX idx_bgg_id (bgg_id),
    INDEX idx_nome (nome_originale(100)),
    INDEX idx_anno (anno_uscita),
    INDEX idx_rating (rating_bgg)
) ENGINE=InnoDB COMMENT='Anagrafica giochi con metadati BGG';


-- =====================================================================
-- 4. TABELLA DIMENSIONE: DIM_DATA
-- =====================================================================
-- Tabella delle date per drill-down temporali (anno/mese/giorno)
CREATE TABLE dim_data (
    id_data         INT PRIMARY KEY,        -- formato AAAAMMGG
    data_completa   DATE NOT NULL,
    anno            INT NOT NULL,
    trimestre       INT NOT NULL,
    mese            INT NOT NULL,
    nome_mese       VARCHAR(20) NOT NULL,
    giorno          INT NOT NULL,
    giorno_settimana VARCHAR(20) NOT NULL,
    settimana       INT NOT NULL,
    
    INDEX idx_anno (anno),
    INDEX idx_mese (anno, mese)
) ENGINE=InnoDB COMMENT='Dimensione temporale per drill-down';


-- =====================================================================
-- 5. TABELLA FATTI: PREZZO_RILEVATO
-- =====================================================================
-- Tabella centrale: una riga per ogni rilevazione (gioco × sito × data)
CREATE TABLE prezzo_rilevato (
    id_rilevazione      BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_gioco            INT NOT NULL,
    id_competitor       INT NOT NULL,
    id_data             INT NOT NULL,
    prezzo_attuale      DECIMAL(8,2) NOT NULL,
    prezzo_originale    DECIMAL(8,2),
    sconto_percent      INT,
    disponibile         TINYINT(1) DEFAULT 1,
    url_prodotto        VARCHAR(500),
    
    FOREIGN KEY (id_gioco)      REFERENCES gioco(id_gioco),
    FOREIGN KEY (id_competitor) REFERENCES competitor(id_competitor),
    FOREIGN KEY (id_data)       REFERENCES dim_data(id_data),
    
    INDEX idx_gioco (id_gioco),
    INDEX idx_competitor (id_competitor),
    INDEX idx_data (id_data),
    INDEX idx_prezzo (prezzo_attuale)
) ENGINE=InnoDB COMMENT='Tabella fatti: prezzi rilevati nello scraping';


-- =====================================================================
-- 6. VERIFICA CREAZIONE
-- =====================================================================
-- Mostra le tabelle create
SHOW TABLES;

-- Conta le righe (devono essere tutte 0 dopo la creazione)
SELECT 'competitor' AS tabella, COUNT(*) AS righe FROM competitor
UNION ALL
SELECT 'gioco', COUNT(*) FROM gioco
UNION ALL
SELECT 'dim_data', COUNT(*) FROM dim_data
UNION ALL
SELECT 'prezzo_rilevato', COUNT(*) FROM prezzo_rilevato;
